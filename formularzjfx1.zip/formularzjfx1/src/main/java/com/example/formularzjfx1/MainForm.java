package com.example.formularzjfx1;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.converter.NumberStringConverter;

import java.util.regex.Pattern;

public class MainForm extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Formularz Danych Osobowych");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 20, 20, 20));

        // Imię
        TextField firstNameField = createTextField("Imię:");
        grid.add(firstNameField, 0, 0);

        // Nazwisko
        TextField lastNameField = createTextField("Nazwisko:");
        grid.add(lastNameField, 0, 1);

        // Adres
        TextField addressField = createTextField("Adres:");
        grid.add(addressField, 0, 2);

        // Miejscowość
        TextField cityField = createTextField("Miejscowość:");
        grid.add(cityField, 0, 3);

        // Telefon
        TextField phoneField = createTextField("Telefon:");
        phoneField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                phoneField.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        grid.add(phoneField, 0, 4);

        // Email
        TextField emailField = createTextField("Email:");
        grid.add(emailField, 0, 5);

        // Przycisk "Zatwierdź"
        Button submitButton = new Button("Zatwierdź");
        submitButton.setDisable(true);
        grid.add(submitButton, 0, 6);

        // Przycisk "Reset"
        Button resetButton = new Button("Reset");
        grid.add(resetButton, 1, 6);

        // Walidacja pól
        validateTextField(firstNameField, "[a-zA-Z]+", 2, "Imię musi składać się z liter i mieć co najmniej 2 znaki.");
        validateTextField(lastNameField, "[a-zA-Z]+", 2, "Nazwisko musi składać się z liter i mieć co najmniej 2 znaki.");
        validateTextField(addressField, ".+", 0, "Adres nie może być pusty.");
        validateTextField(cityField, "[a-zA-Z]+", 3, "Miejscowość musi składać się z liter i mieć co najmniej 3 znaki.");
        validateTextField(phoneField, "\\d{9,}", 0, "Numer telefonu musi składać się z co najmniej 9 cyfr.");
        validateTextField(emailField, "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}", 0, "Nieprawidłowy format adresu email.");

        // Obsługa przycisku "Zatwierdź"
        submitButton.setOnAction(e -> {
            // Tutaj możesz umieścić kod obsługujący zatwierdzenie formularza
            System.out.println("Formularz zatwierdzony!");
        });

        // Obsługa przycisku "Reset"
        resetButton.setOnAction(e -> {
            // Tutaj możesz umieścić kod obsługujący reset formularza
            firstNameField.clear();
            lastNameField.clear();
            addressField.clear();
            cityField.clear();
            phoneField.clear();
            emailField.clear();
        });

        // Aktywacja przycisku "Zatwierdź" tylko wtedy, gdy wszystkie pola są poprawnie wypełnione
        submitButton.disableProperty().bind(
                firstNameField.styleProperty().isEqualTo("-fx-border-color: red;").or(
                        lastNameField.styleProperty().isEqualTo("-fx-border-color: red;")).or(
                        addressField.styleProperty().isEqualTo("-fx-border-color: red;")).or(
                        cityField.styleProperty().isEqualTo("-fx-border-color: red;")).or(
                        phoneField.styleProperty().isEqualTo("-fx-border-color: red;")).or(
                        emailField.styleProperty().isEqualTo("-fx-border-color: red;")));

        Scene scene = new Scene(grid, 400, 300);
        primaryStage.setScene(scene);

        primaryStage.show();
    }

    private TextField createTextField(String promptText) {
        TextField textField = new TextField();
        textField.setPromptText(promptText);
        return textField;
    }

    private void validateTextField(TextField textField, String pattern, int minLength, String errorMessage) {
        textField.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue) {
                String text = textField.getText();
                if (text.length() < minLength || !Pattern.matches(pattern, text)) {
                    textField.setStyle("-fx-border-color: red;");
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText(null);
                    alert.setContentText(errorMessage);
                    alert.showAndWait();
                } else {
                    textField.setStyle(null);
                }
            }
        });
    }
}
