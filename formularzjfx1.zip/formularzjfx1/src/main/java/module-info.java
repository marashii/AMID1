module com.example.formularzjfx1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.formularzjfx1 to javafx.fxml;
    exports com.example.formularzjfx1;
}